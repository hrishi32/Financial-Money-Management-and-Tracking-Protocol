<!DOCTYPE html>
<html>
<head>
	<title>View Request <?php echo $_GET['id']; $reqId=$_GET['id']; ?></title>
</head>
<body>
<?php 
include('config.php');
	$sql = "SELECT * FROM `Request` WHERE reqId = $reqId";
	// echo $sql;
	$result = mysqli_query($db,$sql);
	?>
	<form action="changeAmnt.php" method="post">
	<?php
	if($result) {
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

		?>
		<li><strong>Source:</strong> <?php echo $row['srcAcc']; ?><br/>
		<li><strong>Destination:</strong> <?php echo $row['destAcc']; ?><br/>
		<li><strong>approved:</strong> <?php echo $row['approved']; ?><br/>
		<!-- <li><strong>post:</strong> <?php echo $row['tag'] ?><br/> -->
		 <input type='integer' name='amount' value=<?php echo $row['amount'] ;?> ><br>
		<input type='hidden' name='reqId' value=<?php echo $_GET['id']; ?> >
		<input type='submit' value='Update and audit Request'>
		<?php 
	} 
	else {
		echo "No requests found with that requestID";
	}
?>
<br>
Request ID: <?php echo $_GET['id']; ?>

</body>
</html>